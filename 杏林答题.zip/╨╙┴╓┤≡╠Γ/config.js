module.exports = {
  url: 'https://dt.jingyiban.cn/api/v1/',
  // uid: wx.getStorageSync('uid') ? wx.getStorageSync('uid'):0
}