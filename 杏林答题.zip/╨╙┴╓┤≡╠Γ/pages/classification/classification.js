// pages/classification/classification.js
const URL=require("../../config.js").url;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    flag: 0,
    currentTab: 0,
    allTypes: '',
    computer: [],
    foreignLanguages: [],
    medicine: [],
    politics: [],
    yixuexinxi: [],
    classList: '',
    second_list: ''
  },

  switchNav: function (e) {
    var page = this;
    var id = e.target.id;
    //console.log("id:",id);
    
    // 设置右方显示内容跳转
    if (this.data.currentTab == id) {
      return false;
    } else {
      page.setData({
        second_list: this.data.classList[parseInt(id)].list,
        currentTab: id,
      });
    }
    //console.log("second_list:", this.data.second_list);
    
    //左方选择效果
    page.setData({
      flag: id
    });
  },

  check_user(e){
    // console.log(e.target.id)
    const Uid=wx.getStorageSync('uid');
    // console.log(Uid)
    if (Uid == '') {
      wx.showModal({
        title: '提示',
        content: '请先登录',
        showCancel: false,
        success: (res) => {
          if (res.confirm) {
            wx.switchTab({
              url: '../mine/mine',
            })
          }
        }
      })
    }else{
      wx.navigateTo({
        url: '../practice/practice?id=' + e.target.id,
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: URL+'/classify/list',
      success:(res)=>{
        //console.log(res.data.data);
        this.setData({
          classList: res.data.data,
          second_list: res.data.data[this.data.currentTab].list
        });
        //console.log("class_list:", this.data.classList)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})