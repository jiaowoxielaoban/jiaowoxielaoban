const app=getApp();
const time=app.globalData.time;
const URL=require('../../config.js').url;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [
      // { icon: 'iconfont icon-tiku', title: '我的错库', url: "../questionBank/questionBank"},
      { icon: 'iconfont icon-collect', title: '我的收藏', url:"../collect/collect"},
      { icon: 'iconfont icon-yejian', title: '夜间模式', url: '' },
      { icon: 'iconfont icon-bangzhu', title: '帮助与反馈', url: '../feed/feed'},
      { icon: 'iconfont icon-guanyuwomen', title: '关于我们', url: './about_us/about_us' },
    ],
    time: time,
    box:true,
    user: false,
    userList: [],
    dark: false,
    check: false,
  
  },

  //夜间模式
  dark_change(e){
    wx.showToast({
      title: '功能暂未开放',
      icon: 'none'
    })
    this.setData({
      check: false
    })
  },


  check_uid(e){
    //console.log('e:',e)
    var index = e.currentTarget.id;
    if(wx.getStorageSync('uid').length==0){
      wx.showToast({
        title: '请登录！',
        icon: 'none',
        duration: 1000
      })
      this.setData({
        user: false
      })
      return
    }
    wx.navigateTo({
      url: this.data.list[index].url,
    })
  },

  //获取用户信息
  bindgetuserinfo(e){
    //console.log("e",e)
    if(e.detail.userInfo){
      wx.login({
        success:(res)=>{
          //console.log("res:",res);
         let code = res.code
          if (code!=''){
            wx.request({
              url: 'https://dt.jingyiban.cn/api/v1/user/login',
              method: 'post',
              data: {
                type: "WX",
                code: code,
                userInfo: e.detail.userInfo
              },
              success: (s) => {
                // console.log('succe', res.code)
                wx.setStorageSync('userInfo', e.detail.userInfo);
                wx.setStorageSync('uid', s.data.data.id);
                this.setData({
                  user: true,
                  userList: e.detail.userInfo
                })
                return
              },
              fail: (s) => {
                //console.log('数据库出错');
              }
            })
          }
          else{
            wx.showToast({
              title: '服务器错误',
              duration: 500,
             
            })
          }

        },
        fail:(res)=>{
          //console.log('err:',res)
        }
      })
    }
    
    this.onLoad()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (wx.getStorageSync('uid') && wx.getStorageSync('userInfo')) {
      this.setData({
        userList: wx.getStorageSync('userInfo'),
        user: true
      })
    }else{
      this.setData({
        user: false
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})