var util = require('../../utils/util.js');
const time=getApp().globalData.time;
const URL=require('../../config.js').url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [
      { title: '历年真题', desc: '历年真题汇编', icon: 'iconfont icon-linianzhenti'},
      { title: '错题训练', desc: '错题归纳与收藏练习', icon: 'iconfont icon-cuoti' },
      { title: '自定义题库', desc: '自主上传题目，随时可练习', icon: 'iconfont icon-zidingyi' }
    ],
    time: time,
    img:[],
    advertise: [],
  },

  //未开放的功能
  notOpen(){
    wx.showToast({
      title: '功能暂未开放',
      icon: 'none',
      duration: 1000
    })
  },

  //广告
  advs(){
    wx.request({
      url: URL+'advert/list',
      success:(res)=>{
        this.setData({
          advertise: res.data.data
        })
        // console.log(res);
      }
    })
  },  

  //做题前，检查用户是否登录
  check_user:()=>{
    if(wx.getStorageSync('uid')!=""){
      wx.switchTab({
        url: '../classification/classification',
      })
    }else{
      wx.showModal({
        title: '提示',
        content: '请先登录',
        showCancel: false,
        success:(res)=>{
          if(res.confirm){
            wx.switchTab({
              url: '../mine/mine',
            })
          }
        }
      })
    }
    
  },

  //广告详情
  Goto:(res)=>{
    wx.navigateTo({
      url: '../advertise/advertise?id='+res.currentTarget.id,
    })
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.advs()
    var TIME = util.formatTime(new Date());
    this.setData({
      time: TIME,
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})