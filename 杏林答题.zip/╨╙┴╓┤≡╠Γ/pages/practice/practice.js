// pages/practice/practice.js
const URL = require('../../config.js').url;
let demo1 = []; //单选多选判断
let demo2 = []; //简答题

Page({
  data: {
    flag: "0",    //答题or背题
    flag1: false,   //用户收藏
    list: [],   //题目列表
    tag: 0,   //题目索引
    check: false,
    check_a: false,
    check_b: false,
    check_c: false,
    check_d: false,   //四个答案选项
    my_answer: '',    //用户的答案
    judge: false,   //显示答案和详解
    xuanxiang: [],  //底部导航栏选项
    showmodal: false,   //底部导航栏选项路由跳转界面
    textarea: "",       //简答问答的答案填写框
    disable: true     //控制简答问答输入文本框的状态
  },

  // 点击选项显示modal
  showmodal() {
    //console.log(this.data.xuanxiang)
    this.setData({
      showmodal: !this.data.showmodal,
    })
  },
  // 点击题号跳转至界面
  showPage(e) {
    //console.log(e.target.id);
    var id = parseInt(e.target.id);
    this.setData({ 
      tag: id-1,
      showmodal: false
    })
    this.onLoad();
  },
  // 已经显示modal，用户点击其他区域便隐藏此modal
  hidemodal(){
    if(this.data.showmodal){
      this.setData({
        showmodal: false
      })
    }
  },

  // 本套试卷最后一题
  last_question(){
    if (this.data.tag >= wx.getStorageSync('demo1').length) {
      wx.showModal({
        title: '提示',
        content: '您已答完本次所有试题，再换一张试卷吧',
        showCancel: false,
        success(res) {
          if (res.confirm) {
            wx.switchTab({
              url: '../index/index',
            })
            wx.showToast({
              title: '练习暂时没有评分哦',
              icon: 'none'
            })
          }
        }
      })
      return
    }
  },
  //没有试题
  check_data(){
    if(wx.getStorageSync('demo1').length==0){
      wx.showModal({
        title: '',
        content: '此试卷暂无题',
        showCancel: false,
        success(res){
          if(res.confirm){
            wx.switchTab({
              url: '../classification/classification',
            })
          }
        }
      })
    }
    return
  },

  jianda_change(e){
    this.setData({
      textarea: e.detail.value
    })
    //console.log(this.data.textarea)
  },
  
  //问答简答
  jianda_confirm(e){
    this.last_question();
    if(textarea==this.data.list.answer){
      wx.showToast({
        title: '正确',
      })
      setTimeout(() => {
        this.setData({
          tag: this.data.tag + 1
        })
        this.setData({
          check: false
        })
        this.onLoad()
      }, 500)
    } else {
      //回答错误
      this.setData({
        my_answer: e.detail.value,
        judge: true
      })
    }
  },
  //多选提交
  submit_duoxuan(e) {
    this.last_question();
    if (this.data.my_answer == '') {
      wx.showToast({
        title: '请选择',
        icon: 'none'
      })
      return
    }
    let arr=this.data.my_answer;
    arr.sort();
    //console.log(arr);
    let str='';
    for(var i=0; i<arr.length; i++){
      str+=arr[i];
    }
    //console.log('str:',str);
    //console.log('list:', this.data.list.answer);
    if (str == this.data.list.answer) {
      wx.showToast({
        title: '正确',
      })
      setTimeout(() => {
        this.setData({
          tag: this.data.tag + 1
        })
        this.setData({
          check: false
        })
        this.onLoad()
      }, 500)
    } else {
      //回答错误
        this.setData({
          judge: true
        })
    }

  },

  // 单选、判断题
  change(e) {
    //console.log(e)
    this.last_question();
    this.setData({
      my_answer: e.detail.value
    })
    //console.log(this.data.my_answer)

    if (this.data.list.type == "单选") {
      if (this.data.list.answer == this.data.my_answer) {
        //回答正确
        wx.showToast({
          title: '正确',
        })
        setTimeout(() => {
          this.setData({
            tag: this.data.tag + 1,
            check: false
          })
          this.onLoad();
        }, 500)
      } else {
        //回答错误
        this.setData({
          judge: true
        })
      }
    }
    if (this.data.list.type == "判断") {
      if (this.data.list.answer == this.data.my_answer) {
        //回答正确
        wx.showToast({
          title: '正确',
        })
        setTimeout(() => {
          this.setData({
            tag: this.data.tag + 1,
            jianda_tag: this.data.jianda_tag + 1,
            check: false
          })
          this.onLoad();
        }, 500)
      } else {
        //回答错误
        this.setData({
          judge: true
        })
      }
    }
  },

  //点击上一题
  shangyiti(e) {
    this.last_question();
    if (this.data.tag == 0) {
      wx.showToast({
        title: '已经到头啦',
        icon: 'none'
      })
      return
    }
    this.setData({ tag: this.data.tag-1})
    this.onLoad();

  },

  //交卷
  jiaojuan(e) {
    wx.showModal({
      title: '提示',
      content: '确定要提交试卷吗',
      success(res) {
        if (res.confirm) {
          wx.switchTab({
            url: '../index/index',
          })
          wx.showToast({
            title: '练习暂时没有评分哦',
            icon: 'none'
          })
        } else if (res.cancel) {
          //console.log('取消')
        }
      }
    })
  },

  //下一题
  xiayiti(e) {
    this.last_question();
    if (this.data.tag + 1 >= wx.getStorageSync('demo1').length) {
      wx.showToast({
        title: '已经到底啦',
        icon: 'none'
      })
      return
    }
    this.setData({
      tag: this.data.tag+1 
    })

    this.onLoad();
  },

  //选择背题模式or答题模式
  moshi: function(e) {
    let id = e.target.id;
    this.setData({
      flag: id
    });
  },

  //是否收藏本题
  shoucang() {
    this.setData({
      flag1: !this.data.flag1
    });
    //console.log('flag1:', this.data.flag1)
    //收藏
    wx.request({
      url: URL + 'record/get',
      method: 'post',
      data: {
        uid: wx.getStorageSync('uid'),
        type: this.data.list.type,
        q_id: this.data.list.id,
        fs_id: this.data.list.fs_id,
        is_store: this.data.flag1,
      },
      success: (res) => {
        
        if (this.data.flag1) {
          wx.showToast({
            title: '收藏成功',
            duration: 1000
          })
        } else {
          wx.showToast({
            title: '取消收藏成功',
            duration: 1000
          })
        }
        //console.log(res);
      }
    })
  },

  //请求题库
  getlist(id) {
    wx.request({
      url: URL + 'bank/list?id=' + id,
      success: (res) => {
        //console.log(res.data.data);
        //数据存入缓存
        demo1 = res.data.data.select;
        demo2 = res.data.data.object;
        for(var i in demo2){
          demo1.push(demo2[i]);
        }
        wx.setStorageSync('demo1', res.data.data.select);
        this.check_data()
        this.setData({
          list: demo1[this.data.tag]
        })
        this.initialize_data(); //初始化数据
        //console.log("list_first", this.data.list)
      }
    })
  },
  //用户通过收藏进入此页面
  getCollectList(fs_id){
    wx.request({
      url: URL + 'record/getDetail',
      method: 'post',
      data: {
        uid: wx.getStorageSync('uid'),
        id: fs_id,
        type: 'store'
      },
      success: (res) => {
        //console.log("collect_detai:", res);
        wx.setStorageSync('demo1', res.data.data);
        wx.setStorageSync('store', true);   //存入缓存
        this.setData({
          list: wx.getStorageSync('demo1')[this.data.tag],
          flag1: true
        })    
        this.initialize_data(); //初始化数据
        // console.log("list_store", this.data.list);
      }
    })
  },

  //初始化数据
  initialize_data(){
    if (wx.getStorageSync('store')) {
      //我的收藏页面进入
      this.setData({
        flag1: true //收藏图标显示
      })
    } else {
      this.setData({
        flag1: false,
        judge: false,
        check: false,
        textarea: ''
      })
      // 动态加载选项内容
      let arr = new Array();
      for (var i = 0; i < wx.getStorageSync('demo1').length; i++) {
        arr[i] = i + 1;
      }
      this.setData({
        xuanxiang: arr
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //请求数据&存入缓存
    if (wx.getStorageSync('id') == '') {
      //第一次进入答题页面
      if (options.type == 'store') {
        //我的收藏
        this.getCollectList(options.id);
      } else if (options.type == 'is_right') {
        //我的错题

      } else {
        //练习
        this.getlist(options.id);
      }
      wx.setStorageSync('id', options.id);
    } else {
      demo1 = wx.getStorageSync('demo1');
      this.setData({
        list: demo1[this.data.tag]
      })
      this.initialize_data(); //初始化数据
      //console.log("list", this.data.list);
    }
    // console.log('tag(页面索引)：' + this.data.tag);

    
    //背题模式下渲染多选选中答案
    if (this.data.flag == 1) {
      this.setData({
        answer_a: false,
        answer_b: false,
        answer_c: false,
        answer_d: false
      })
      for (var i = 0; i < this.data.list.answer.length; i++) {
        if ('A' == this.data.list.answer) {
          this.setData({
            answer_a: true
          })
        }
        if ('B' == this.data.list.answer) {
          this.setData({
            answer_b: true
          })
        }
        if ('C' == this.data.list.answer) {
          this.setData({
            answer_c: true
          })
        }
        if ('D' == this.data.list.answer) {
          this.setData({
            answer_d: true
          })
        }
      }
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    wx.removeStorageSync('id');
    wx.removeStorageSync('demo1');
    wx.removeStorageSync('store');
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})