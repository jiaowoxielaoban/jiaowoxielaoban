// pages/feed/feed.js
const URL=require('../../config.js').url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    content: '',
    contact: '',
  },

  input_text(e){
    this.setData({
      content: e.detail.value
    })
  },

  input_phone(e){
    this.setData({
      contact: e.detail.value
    })
  },

  //用户反馈
  feed() {
    if(this.data.content){
      wx.request({
        url: URL + 'feed/get',
        method: 'post',
        data: {
          uid: wx.getStorageSync('uid'),
          type: 'feed',
          content: this.data.content,
          contact: this.data.contact
        },
        success: (res) => {
          console.log(res);
          wx.showToast({
            title: '感谢您的反馈',
          });
          wx.switchTab({
            url: '../mine/mine',
          })
        }
      })
    }else{
      wx.showToast({
        title: '输入内容不能为空',
        icon: 'none',
        duration: 1000
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})