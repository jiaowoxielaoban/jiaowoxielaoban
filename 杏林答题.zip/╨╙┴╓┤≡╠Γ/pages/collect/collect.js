// pages/collect/collect.js
const URL=require('../../config.js').url;
const collect_data=[
  {id: 1, grade_1: "医学类", grade_2: "护士执业资格" },
  { id: 2, grade_1: "外语类", grade_2: "大学英语四级" },
  { id: 3, grade_1: "计算机类", grade_2: "二级C语言程序设计" }
]

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    show: true,
    tips: '暂时还没有收藏的题，快去收藏吧！'
  },

  //获取收藏的题
  collect(){
    wx.request({
      url: URL+'record/list',
      method: 'post',
      data:{
        uid: wx.getStorageSync('uid'),
        type: 'store'
      },
      success:(res)=>{
        //console.log(res.data.data)
        if(res.data.data.length==0){
          this.setData({
            show: false
          })
          return
        }
        this.setData({
          list: res.data.data
        })
      },
      fail:(e)=>{
        //console.log(e)
      }
    })
  },

  //点击跳转到题目详细页面
  collect_detail(e){
    var fs_id=e.currentTarget.id;
    //console.log(fs_id)
    wx.navigateTo({
      url: '../practice/practice?id=' + fs_id +'&type=store',
      fail:(res)=>{
        console.log('err:',res);
      }
    })
    
  },

  //获取此题详细信息
  getcollect_drtail(fs_id) {
    wx.request({
      url: URL + 'record/getDetail',
      method: 'post',
      data: {
        uid: wx.getStorageSync('uid'),
        id: fs_id,
        type: 'store'
      },
      success: (res) => {
        //console.log("collect_detai:", res);
        wx.setStorageSync('demo', res.data.data)
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    wx.setNavigationBarTitle({
      title: '我的收藏',
    })

    this.collect();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})